# Prática da Semana 4
  
Faça um algoritmo que receba dez alturas de alunos e, depois, exiba, para cada aluno, o número de alturas menores que a sua.

  ## Exemplo de execução do programa
  
  ![Exemplo](assets/F1-M3-Sem04-Praticas-Exemplo.png)

  ## Grade de correção
  ![Grade](assets/F1-M3-Sem04-Praticas-Grade.png)

  ## Objetivos de aprendizagem
  1. Utilizar comandos de repetição aninhados
  2. Utilizar coleções indexadas (array)
  

  