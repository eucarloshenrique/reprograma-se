# Gabarito
![Grade](assets/F1-M3-Sem02-Praticas-Gabarito.png)

# Rubrica de correção
  ![Grade](assets/F1-M3-Sem02-Praticas-Grade.png)