const prompt = require('prompt-sync')();

var alturas = []
var alt;
var menores = [];
var qtd;

// Implementar a entrada de dados
for (var i = 0; i < 10; i++) {
  alt = parseFloat(prompt("Digite a altura: "))
  alturas.push(alt);
}
// Implementar o processamento de dados
// Fazer for dentro de for
for (var i = 0; i < 10; i++) {
  qtd = 0;
  for (var j = 0; j < 10; j++) {
    if (alturas[i] > alturas[j]) {
      qtd++;
    }
  }
  menores.push(qtd);
}
// Implementar a saída de dados
for (var i = 0; i < 10; i++) {
  console.log("Aluno " + i + ": maior que " + menores[i] + " alunos(s)");
  console.log("GABARITO " + i + ": maior que " + menores[i], " aluno(s)");
}